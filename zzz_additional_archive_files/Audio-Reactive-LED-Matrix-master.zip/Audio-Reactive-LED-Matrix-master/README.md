# Audio-Reactive-LED-Matrix
Update: Use the new final .ino file, instead of the code in the Baby Speaker folder.

Code for 16x16 LED Matrix (WS2812) that reacts to sounds detected from an electret microphone, and switches modes with a momentary push button.  Based on FastLED library, and runs best on Arduino Mega.


Video showing this in action is here: https://youtu.be/X1bEgGLwVLY
